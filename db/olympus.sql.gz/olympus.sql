-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 19, 2017 at 01:09 AM
-- Server version: 5.6.35
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `olympus`
--

-- --------------------------------------------------------

--
-- Table structure for table `wg_category`
--

CREATE TABLE `wg_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `priority` tinyint(4) NOT NULL DEFAULT '1',
  `type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('active','deactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `param` text COLLATE utf8_unicode_ci,
  `visit` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `pageview` int(10) UNSIGNED DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_category`
--

INSERT INTO `wg_category` (`id`, `parent`, `priority`, `type`, `status`, `param`, `visit`, `pageview`, `created_at`, `updated_at`) VALUES
(25, 0, 1, 'product', 'active', '{\"show_category\":false,\"show_post\":false}', 1, 1, '2016-07-27 17:39:46', '2017-03-27 07:59:27'),
(26, 0, 2, 'product', 'active', '{\"show_category\":false,\"show_post\":false}', 1, 1, '2016-07-27 17:44:01', '2017-03-27 07:59:37'),
(105, 0, 2, 'post', 'active', '{\"show_category\":false,\"show_post\":false}', 5, 8, '2016-08-18 12:58:38', '2017-04-06 08:48:11'),
(106, 0, 1, 'post', 'active', '{\"show_category\":true,\"show_post\":false}', 10, 30, '2016-08-18 12:58:47', '2017-04-06 08:48:05'),
(112, 0, 4, 'post', 'active', '{\"show_category\":false,\"show_post\":false}', 2, 3, '2016-08-18 13:02:08', '2017-04-06 08:48:27'),
(113, 0, 3, 'post', 'active', '{\"show_category\":false,\"show_post\":false}', 2, 4, '2016-09-19 10:57:53', '2017-04-06 08:48:18'),
(115, 0, 1, 'banner', 'active', '{\"show_category\":false,\"show_post\":false}', 12, 21, '2016-10-24 17:18:22', '2017-03-31 20:49:00'),
(116, 0, 2, 'banner', 'active', '{\"show_category\":false,\"show_post\":false}', 10, 52, '2016-10-24 17:19:17', '2017-03-31 20:29:52'),
(119, 0, 3, 'banner', 'active', '{\"show_category\":false,\"show_post\":true}', 1, 1, '2017-04-06 08:21:52', '0000-00-00 00:00:00'),
(120, 112, 1, 'post', 'active', '{\"show_category\":false,\"show_post\":true}', 2, 4, '2017-04-06 08:48:39', '2017-04-06 09:48:41'),
(121, 112, 2, 'post', 'active', '{\"show_category\":false,\"show_post\":true}', 1, 1, '2017-04-06 08:48:53', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `wg_content`
--

CREATE TABLE `wg_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `lang` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `tbl` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_content`
--

INSERT INTO `wg_content` (`id`, `lang`, `tbl`, `title`, `alias`, `content`) VALUES
(1, 'vi', 'menu', 'Main menu', 'main-menu', NULL),
(2, 'vi', 'widget', 'Main menu', 'main-menu', NULL),
(8, 'vi', 'widget', 'Revolution', 'revolution', NULL),
(9, 'vi', 'widget', 'Khách hàng', 'khach-hang', '<section>\n<div class=\"container\">\n<div class=\"row\">\n<div class=\"col-xs-8\">\n<h3 class=\"heading\">Khách hàng của chúng tôi</h3>\n<div class=\"client-1\">\n<div class=\"client-model\"><img src=\"/images/home/model-client.png\" alt=\"model-client\" width=\"250\" caption=\"false\" style=\"display: block; margin-left: auto; margin-right: auto;\" height=\"275\" /></div>\n<div class=\"row\" style=\"background: gray;\"><img src=\"/images/home/client-logo-1.png\" alt=\"client-logo-1\" class=\"col-xs-4\" width=\"360\" height=\"200\" caption=\"false\" /> <img src=\"/images/home/client-logo-2.png\" alt=\"client-logo-2\" class=\"col-xs-4\" height=\"200\" caption=\"false\" width=\"360\" /> <img src=\"/images/home/client-logo-3.png\" alt=\"client-logo-3\" class=\"col-xs-4\" width=\"360\" height=\"200\" caption=\"false\" /> <img src=\"/images/home/client-logo-4.png\" alt=\"client-logo-4\" class=\"col-xs-4\" width=\"360\" height=\"200\" caption=\"false\" /> <img src=\"/images/home/client-logo-5.png\" alt=\"client-logo-5\" class=\"col-xs-4\" width=\"360\" height=\"200\" caption=\"false\" /> <img src=\"/images/home/client-logo-6.png\" alt=\"client-logo-6\" class=\"col-xs-4\" width=\"360\" height=\"200\" caption=\"false\" /></div>\n</div>\n</div>\n<div class=\"col-xs-4\">\n<h3 class=\"heading effect-loaded\">Testimonial</h3>\n<div class=\"testimonial\">\n<ul class=\"list-unstyled\">\n<li class=\"clearfix effect-loaded\">\n<div class=\"text\"><i class=\"point-client icon-caret-down\"></i><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna</span></div>\n<p class=\"client-info clearfix\"><img src=\"/images/home/client-avatar-1.jpg\" alt=\"client-avatar-1\" width=\"120\" height=\"120\" caption=\"false\" /> <strong class=\"client-name\">John Doe</strong> <i class=\"client-meta\">CEO ThemeTan</i></p>\n</li>\n</ul>\n</div>\n</div>\n</div>\n</div>\n</section>\n<section id=\"page-section-6\" class=\"page-section\">\n<div class=\"container\">\n<div class=\"row clearfix no-padding\">\n<div class=\"col-lg-12 effect-loaded\">\n<h2 class=\"no-padding\">Liên hệ ngay: (848) - 6680 1428 - Hotline: 0906 21 23 90</h2>\n<h4 class=\"no-padding\">hoặc có thể liên lạc với chúng tôi bằng email: <a class=\"color\">info@wedesignplus.com</a></h4>\n</div>\n</div>\n</div>\n</section>'),
(10, 'vi', 'widget', 'Dịch vụ', 'dich-vu', '<div class=\"features\">\n<div class=\"container\">\n<div class=\"row\">\n<div class=\"col-xs-4\">\n<div class=\"features-block\"><img src=\"/public/images/home/features-1.png\" class=\"img-responsive\" alt=\"features1\" width=\"47\" height=\"38\" caption=\"false\" /><br />\n<h6 class=\"features-heading\">Quà tặng văn phòng</h6>\n<p>In perfection.</p>\n</div>\n</div>\n<div class=\"col-xs-4\">\n<div class=\"features-block\"><img src=\"/public/images/home/features-2.png\" alt=\"features-1\" width=\"58\" height=\"38\" caption=\"false\" /><br />\n<h6 class=\"features-heading\">In ấn quảng cáo</h6>\n<p>With flexibility.</p>\n</div>\n</div>\n<div class=\"col-xs-4\">\n<div class=\"features-block\"><img src=\"/public/images/home/features-3.png\" class=\"img-responsive\" alt=\"features3\" width=\"32\" height=\"38\" caption=\"false\" /><br />\n<h6 class=\"features-heading\">Thi công quảng cáo</h6>\n<p>With intelligence.</p>\n</div>\n</div>\n</div>\n</div>\n</div>'),
(11, 'vi', 'widget', 'Google map', 'google-map', '<h3>Google Inc.</h3>\n<p>1600 Amphitheatre Parkway<br />Mountain View, CA 94043<br />USA</p>'),
(12, 'vi', 'widget', 'Copyright', 'copyright', '<p><span>© 2016 Bản quyền thuộc về Công Ty TNHH Thương Mại Dịch Vụ &amp; Giải Pháp Việt Nhất. All right reserved · </span><a href=\"#\">Privacy</a><span> · </span><a href=\"#\">Terms</a></p>'),
(13, 'vi', 'widget', 'Footer menu', 'footer-menu', ''),
(14, 'vi', 'widget', 'Hỗ trợ trực tuyến', 'ho-tro-truc-tuyen', '<p>Custom HTML</p>'),
(15, 'vi', 'widget', 'Thống kê truy cập', 'thong-ke-truy-cap', NULL),
(16, 'vi', 'widget', 'Thông tin công ty', 'thong-tin-cong-ty', '<h3>Google Inc.</h3>\n<p>1600 Amphitheatre Parkway<br />Mountain View, CA 94043<br />USA</p>'),
(17, 'vi', 'widget', 'Giới thiệu', 'gioi-thieu', '<div id=\"footer-about\">\n<p>Công ty TNNH TMDV &amp; Giải Pháp <strong>Việt Nhất</strong> chuyên thiết kế Website, cung cấp Hosting và Domain dựa trên năng lực lõi là những chuyên gia thiết kế, lập trình thiết kế website hàng đầu từ phòng phát triển Web của chúng tôi.</p>\n<p>Với <strong>Việt</strong><strong> Nhất </strong>luôn mang đến khách hàng những dịch vụ với chi phí hợp lí, chất lượng quốc tế, phục vụ chuyên nghiệp, hậu mãi chu đáo.</p>\n</div>'),
(18, 'vi', 'widget', 'Subcribe', 'subcribe', '<p>Subcribe</p>'),
(19, 'vi', 'widget', 'Fanpage', 'fanpage', '<p><iframe width=\"300\" height=\"300\" style=\"border: none; overflow: hidden; width: 100%; height: 258px;\" src=\"http://www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fvietnhatsolutions&amp;width=292&amp;height=258&amp;colorscheme=dark&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=false\" scrolling=\"no\" frameborder=\"0\" allowtransparency=\"true\"></iframe></p>'),
(20, 'vi', 'widget', 'Tin tức', 'tin-tuc', NULL),
(21, 'vi', 'widget', 'CC slider', 'cc-slider', NULL),
(22, 'vi', 'widget', 'Giới thiệu công ty', 'gioi-thieu-cong-ty', '<div id=\"about\" class=\"about-main-block mrg-btm\">\n<div class=\"container\">\n<div class=\"section\">\n<h3 class=\"section-heading\">Giới thiệu <span>Công ty Thái Sơn Olympus</span></h3>\n</div>\n<div class=\"row\">\n<div class=\"col-xs-offset-1 col-sm-7 col-md-5\">\n<div class=\"about-block\">\n<h2 class=\"middle-heading\">We are the <span>leaders</span></h2>\n<p>We are a team of young and enthusiastic designers and developers who developed Layers WP Style Kit, WP Themes, Layers WP Child Theme, Bootstrap Themes, WP Themes, Opencart Themes, Joomla Themes and PSD Templates. Our mission is to build user–friendly, clean and modern designs in order to help more and more users improve their livelihood. To us, customer is king.</p>\n</div>\n<div class=\"about-facts\">\n<div class=\"row\">\n<div class=\"col-xs-4\">\n<h2 class=\"counter\">318</h2>\n<p>Nhân sự</p>\n</div>\n<div class=\"col-xs-4\">\n<h2 class=\"counter\">4021</h2>\n<p>Khách hàng</p>\n</div>\n<div class=\"col-xs-4\">\n<h2 class=\"counter\">28</h2>\n<p>Giải thưởng</p>\n</div>\n</div>\n</div>\n</div>\n<div class=\"col-md-offset-2 col-sm-4 col-md-4\">\n<div class=\"about-dtl-img img-top\"><img src=\"/public/images/home/about-image.jpg\" class=\"img-responsive\" alt=\"about\" width=\"370\" height=\"514\" caption=\"false\" /></div>\n</div>\n</div>\n</div>\n</div>'),
(23, 'vi', 'widget', 'Download catelogue', 'download-catelogue', '<div class=\"requst-quotation\">\n<div class=\"container\">\n<div class=\"row\">\n<div class=\"col-sm-3\">\n<div class=\"quotation-img\"><img src=\"/public/images/home/quotation-icon.png\" class=\"img-responsive\" alt=\"quotation\" width=\"268\" height=\"255\" caption=\"false\" /></div>\n</div>\n<div class=\"col-sm-9\">\n<div class=\"quotation-dtl\">\n<h2 class=\"middle-heading\">Download <span>catelogue</span></h2>\n<p>We are a team of young and enthusiastic designers, marketers and developers who are specialized at creating professional.</p>\n</div>\n</div>\n</div>\n</div>\n</div>'),
(24, 'vi', 'widget', 'Service tab', 'service-tab', '<div id=\"services\" class=\"services-main-block mrg-btm\">\n<div class=\"container\">\n<div class=\"section\">\n<h3 class=\"section-heading-rgt\">Dịch vụ <span>của chúng tôi</span></h3>\n</div>\n<div class=\"services-tab\">\n<ul class=\"nav nav-tabs\" role=\"tablist\">\n<li role=\"presentation\" class=\"active\"><a href=\"/index.html#service-01\" aria-controls=\"service-01\" role=\"tab\" data-toggle=\"tab\">Quà tặng văn phòng</a></li>\n<li role=\"presentation\"><a href=\"/index.html#service-02\" aria-controls=\"service-02\" role=\"tab\" data-toggle=\"tab\">In ấn quảng cáo</a></li>\n<li role=\"presentation\"><a href=\"/index.html#service-03\" aria-controls=\"service-03\" role=\"tab\" data-toggle=\"tab\">Thi công quảng cáo</a></li>\n</ul>\n</div>\n<div class=\"tab-content\">\n<div role=\"tabpanel\" class=\"tab-pane active\" id=\"service-01\">\n<div class=\"row\">\n<div class=\"col-sm-4 col-md-4\">\n<div class=\"service-img\"><a href=\"/services-details.html\"> <img src=\"/public/images/home/service-01.png\" class=\"img-responsive\" alt=\"service-01\" width=\"370\" height=\"317\" caption=\"false\" /> </a></div>\n</div>\n<div class=\"col-md-offset-3 col-sm-offset-1 col-sm-6 col-md-4\">\n<div class=\"service-dtl\">\n<h2 class=\"middle-heading text-align-right\">3D print <span>service</span></h2>\n<p class=\"text-align-right\">Over the past 9 years Printogram\'s 3D department has established a leading position in providing professional 3D print services. Supplying equipment from 3D Systems and software from Materialise we have specialised our expertise in these products and backed it up through our internationally renowned 3D bureau service. Our 3D clients include top international Architectural.</p>\n</div>\n</div>\n</div>\n</div>\n<div role=\"tabpanel\" class=\"tab-pane\" id=\"service-02\">\n<div class=\"row\">\n<div class=\"col-sm-4 col-md-4\">\n<div class=\"service-img\"><a href=\"/services-details.html\"> <img src=\"/public/images/home/service-02.png\" class=\"img-responsive\" alt=\"service-02\" /> </a></div>\n</div>\n<div class=\"col-md-offset-3 col-sm-offset-1 col-sm-6 col-md-4\">\n<div class=\"service-dtl\">\n<h2 class=\"middle-heading text-align-right\">Digital <span>print</span></h2>\n<p class=\"text-align-right\">Lorem ipsum dolor sit amet, eu pri detraxit indoctum. Epicurei perfecto periculis in qui, sed eu persius ornatus, et malorum sensibus philosophia pri. Et usu dicam aeterno honestatis. Vel dicam petentium vituperata an, omnis posse legimus sea te. Vis ut reque facer. Vidit detraxit democritum ut nec, ut mea evertitur temporibus. Cum cu labitur senserit, ex eos appetere reformidans.</p>\n</div>\n</div>\n</div>\n</div>\n<div role=\"tabpanel\" class=\"tab-pane\" id=\"service-03\">\n<div class=\"row\">\n<div class=\"col-sm-4 col-md-4\">\n<div class=\"service-img\"><a href=\"/services-details.html\"> <img src=\"/public/images/home/service-03.png\" class=\"img-responsive\" alt=\"service-03\" /> </a></div>\n</div>\n<div class=\"col-md-offset-3 col-sm-offset-1 col-sm-6 col-md-4\">\n<div class=\"service-dtl\">\n<h2 class=\"middle-heading text-align-right\">Leflets <span>print</span></h2>\n<p class=\"text-align-right\">We are a team of young and enthusiastic designers and developers who developed Layers WP Style Kit, WP Themes, Layers WP Child Theme, Bootstrap Themes, WP Themes, Opencart Themes, Joomla Themes and PSD Templates. Our mission is to build user–friendly, clean and modern designs in order to help more and more users improve their livelihood. To us, customer is king.</p>\n</div>\n</div>\n</div>\n</div>\n</div>\n</div>\n</div>'),
(25, 'vi', 'category', 'Horn Contreras Inc ', 'horn-contreras-inc', NULL),
(25, 'vi', 'widget', 'In ấn', 'in-an', '<div class=\"idea\">\n<div class=\"container\">\n<div class=\"idea-block\">\n<h3 class=\"block-heading clr-white\">IN ẤN</h3>\n<p class=\"clr-white\">Là một công ty In ấn chuyên nghiệp và hoạt động về lĩnh vực in ấn trong nhiều năm, sản phẩm in ấn và dịch vụ của chúng tôi cung cấp đa dạng và nhiều hình thức như: Danh thiếp, biểu mẫu văn phòng (Phiếu xuất - nhập kho, phiếu ra vào cổng, biên nhận bán hàng...), giấy tiêu đề, tem, nhãn, bao thư, folder, brochure, lịch, sổ tay, thiệp chúc mừng, thiệp mời, bằng khen, giấy chứng nhận, bao bì, túix ách giấy, catalogue,…</p>\n</div>\n</div>\n</div>'),
(26, 'vi', 'category', 'Fitzpatrick and Harris Plc', 'fitzpatrick-and-harris-plc', NULL),
(26, 'vi', 'widget', 'Quà tặng', 'qua-tang', '<div class=\"idea\">\n<div class=\"container\">\n<div class=\"idea-block\">\n<h3 class=\"block-heading clr-white\">QUÀ TẶNG</h3>\n<p class=\"clr-white\">Tặng quà là cách chúng ta thể hiện sự quan tâm đến nhau. Chúng tôi mong muốn là cầu nối trung gian giữa doanh nghiệp và khách hàng chia sẻ, gửi gắm tâm nguyện của mình vào một món quà ý nghĩa. Đến với chúng tôi là bạn được đến với thế giới của quà tặng và ở đây bạn có thể an tâm khi gửi niềm tin của mình. Chúng tôi mang đến nhiều mặt hàng để quý khách hàng lựa chọn cho các sự kiện quan trọng.</p>\n</div>\n</div>\n</div>'),
(27, 'vi', 'widget', 'Logo partner', 'logo-partner', '<div id=\"clients\" class=\"clients-main-block\">\n<div class=\"container\">\n<div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">\n<ol class=\"carousel-indicators\">\n<li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>\n<li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>\n<li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>\n</ol>\n<div class=\"carousel-inner\" role=\"listbox\">\n<div class=\"item active\">\n<div class=\"row\">\n<div class=\"col-xs-3\"><img src=\"/public/images/home/logo-1.png\" class=\"img-responsive\" alt=\"client-logo1\" /></div>\n<div class=\"col-xs-3\"><img src=\"/public/images/home/logo-2.png\" class=\"img-responsive\" alt=\"client-logo2\" width=\"150\" height=\"150\" caption=\"false\" /></div>\n<div class=\"col-xs-3\"><img src=\"/public/images/home/logo-3.png\" class=\"img-responsive\" alt=\"client-logo3\" /></div>\n<div class=\"col-xs-3\"><img src=\"/public/images/home/logo-4.png\" class=\"img-responsive\" alt=\"client-logo4\" /></div>\n</div>\n</div>\n<div class=\"item\">\n<div class=\"row\">\n<div class=\"col-xs-3\"><img src=\"/public/images/home/logo-5.png\" class=\"img-responsive\" alt=\"client-logo1\" /></div>\n<div class=\"col-xs-3\"><img src=\"/public/images/home/logo-6.png\" class=\"img-responsive\" alt=\"client-logo2\" width=\"150\" height=\"150\" caption=\"false\" /></div>\n<div class=\"col-xs-3\"><img src=\"/public/images/home/logo-1.png\" class=\"img-responsive\" alt=\"client-logo3\" /></div>\n<div class=\"col-xs-3\"><img src=\"/public/images/home/logo-2.png\" class=\"img-responsive\" alt=\"client-logo4\" /></div>\n</div>\n</div>\n</div>\n<a class=\"left carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"prev\"> <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span> <span class=\"sr-only\">Previous</span> </a> <a class=\"right carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"next\"> <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span> <span class=\"sr-only\">Next</span> </a></div>\n</div>\n</div>'),
(100, 'vi', 'menu', 'Trang chủ', 'trang-chu', NULL),
(101, 'vi', 'menu', 'In ấn', 'in-an', NULL),
(102, 'vi', 'menu', 'Custom Url', 'custom-url', NULL),
(103, 'vi', 'menu', 'Separator', 'separator', NULL),
(104, 'vi', 'menu', 'Separator', 'separator', NULL),
(105, 'vi', 'category', 'In ấn', 'in-an', NULL),
(105, 'vi', 'menu', 'Quà tặng', 'qua-tang', NULL),
(106, 'vi', 'category', 'Quà tặng', 'qua-tang', NULL),
(106, 'vi', 'menu', 'Quảng cáo', 'quang-cao', NULL),
(112, 'vi', 'category', 'Tin tức', 'tin-tuc', NULL),
(113, 'vi', 'category', 'Quảng  cáo', 'quang-cao', NULL),
(115, 'vi', 'category', 'Revolution', 'revolution', NULL),
(116, 'vi', 'category', 'CC slider', 'cc-slider', NULL),
(119, 'vi', 'category', 'Product', 'product', NULL),
(120, 'vi', 'category', 'Tin nổi bật', 'tin-noi-bat', NULL),
(121, 'vi', 'category', 'Kỹ thuật in ấn', 'ky-thuat-in-an', NULL),
(124, 'vi', 'menu', 'Nhóm 01', 'nhom-01', NULL),
(125, 'vi', 'menu', 'Nhóm 02', 'nhom-02', NULL),
(126, 'vi', 'menu', 'Nhóm 03', 'nhom-03', NULL),
(130, 'vi', 'menu', 'Liên hệ', 'lien-he', NULL),
(131, 'vi', 'menu', 'Tin tức', 'tin-tuc', NULL),
(132, 'vi', 'menu', 'Sổ tay', 'so-tay', NULL),
(133, 'vi', 'menu', 'Bút bi', 'but-bi', NULL),
(134, 'vi', 'menu', 'Bút kim loại', 'but-kim-loai', NULL),
(135, 'vi', 'menu', 'Áo mưa/ Ô dù', 'ao-mua-o-du', NULL),
(136, 'vi', 'menu', 'Hộp đựng danh thiếp', 'hop-dung-danh-thiep', NULL),
(137, 'vi', 'menu', 'Móc khóa', 'moc-khoa', NULL),
(138, 'vi', 'menu', 'Bình giữ nhiệt', 'binh-giu-nhiet', NULL),
(139, 'vi', 'menu', 'Bộ ly tách thủy tinh/ sứ', 'bo-ly-tach-thuy-tinh-su', NULL),
(140, 'vi', 'menu', 'Bao lô túi xách', 'bao-lo-tui-xach', NULL),
(141, 'vi', 'menu', 'Túi vải k dệt – vải bố', 'tui-vai-k-det-vai-bo', NULL),
(142, 'vi', 'menu', 'Bảng tên – dây treo thẻ Nhân viên', 'bang-ten-day-treo-the-nhan-vien', NULL),
(143, 'vi', 'menu', 'Quạt quảng cáo', 'quat-quang-cao', NULL),
(144, 'vi', 'menu', 'Đồng hồ', 'dong-ho', NULL),
(145, 'vi', 'menu', 'USB', 'usb', NULL),
(146, 'vi', 'menu', 'Nón – Đồng phục', 'non-dong-phuc', NULL),
(147, 'vi', 'menu', 'Ấn phẩm văn phòng', 'an-pham-van-phong', NULL),
(148, 'vi', 'menu', 'Ấn phẩm quảng cáo', 'an-pham-quang-cao', NULL),
(149, 'vi', 'menu', 'Ấn phẩm khác', 'an-pham-khac', NULL),
(150, 'vi', 'menu', 'Name Card', 'name-card', NULL),
(151, 'vi', 'menu', 'Letter Head', 'letter-head', NULL),
(152, 'vi', 'menu', 'Bao Thư', 'bao-thu', NULL),
(153, 'vi', 'menu', 'Bìa đựng hồ sơ', 'bia-dung-ho-so', NULL),
(154, 'vi', 'menu', 'Bút/ Viết', 'but-viet', NULL),
(155, 'vi', 'menu', 'Văn phòng phẩm', 'van-phong-pham', NULL),
(156, 'vi', 'menu', 'Khác', 'khac', NULL),
(157, 'vi', 'menu', 'Tờ rơi / Tờ gấp', 'to-roi-to-gap', NULL),
(158, 'vi', 'menu', 'Brochure / Catalogue / Profile', 'brochure-catalogue-profile', NULL),
(159, 'vi', 'menu', 'Phiếu quà tặng/ Voucher', 'phieu-qua-tang-voucher', NULL),
(160, 'vi', 'menu', 'Thiệp mời / Thiệp cưới', 'thiep-moi-thiep-cuoi', NULL),
(161, 'vi', 'menu', 'Sổ tay', 'so-tay', NULL),
(162, 'vi', 'menu', 'Băng rôn ( Hiflex, PP, Decal, Format, Canvas, Silk) , Giấy ảnh', 'bang-ron-hiflex-pp-decal-format-canvas-silk-giay-anh', NULL),
(163, 'vi', 'menu', 'Thẻ nhựa ( thẻ Vip)', 'the-nhua-the-vip', NULL),
(164, 'vi', 'menu', 'Bao lì xì / Lịch', 'bao-li-xi-lich', NULL),
(165, 'vi', 'menu', 'Khác', 'khac', NULL),
(166, 'vi', 'menu', 'Nhãn Decal giấy', 'nhan-decal-giay', NULL),
(167, 'vi', 'menu', 'Bao bì hộp giấy', 'bao-bi-hop-giay', NULL),
(168, 'vi', 'menu', 'Hộp sản phẩm', 'hop-san-pham', NULL),
(169, 'vi', 'menu', 'Hộp quà', 'hop-qua', NULL),
(170, 'vi', 'menu', 'Bao đựng đũa, giấy trãi bàn nhà hàng / khách sạn', 'bao-dung-dua-giay-trai-ban-nha-hang-khach-san', NULL),
(171, 'vi', 'menu', 'Bao đựng bánh mì', 'bao-dung-banh-mi', NULL),
(172, 'vi', 'menu', 'Bao bì nhựa/ nilon/ màng co', 'bao-bi-nhua-nilon-mang-co', NULL),
(173, 'vi', 'menu', 'Tin nổi bật', 'tin-noi-bat', NULL),
(174, 'vi', 'menu', 'Kỹ thuật in ấn, quảng cáo', 'ky-thuat-in-an-quang-cao', NULL),
(1268, 'vi', 'post', 'Officia atque veritatis temporibus libero ex adipisci aliquip quia nihil', 'officia-atque-veritatis-temporibus-libero-ex-adipisci-aliquip-quia-nihil', NULL),
(1270, 'vi', 'post', 'Beatae aspernatur minus beatae qui unde nihil facere', 'beatae-aspernatur-minus-beatae-qui-unde-nihil-facere', NULL),
(1271, 'vi', 'post', 'Velit recusandae Veniam consequat Molestias do quas earum corrupti dolor harum explicabo Quia autem', 'velit-recusandae-veniam-consequat-molestias-do-quas-earum-corrupti-dolor-harum-explicabo-quia-autem', NULL),
(1272, 'vi', 'post', 'Consequatur consequuntur dicta accusamus cillum lorem duis cillum illum', 'consequatur-consequuntur-dicta-accusamus-cillum-lorem-duis-cillum-illum', NULL),
(1273, 'vi', 'post', 'Numquam pariatur A eius magni consequatur Sint asperiores cum', 'numquam-pariatur-a-eius-magni-consequatur-sint-asperiores-cum', NULL),
(1274, 'vi', 'post', 'Cillum tenetur id ullam accusamus in quas quo soluta quibusdam consectetur', 'cillum-tenetur-id-ullam-accusamus-in-quas-quo-soluta-quibusdam-consectetur', NULL),
(1275, 'vi', 'post', 'At ut amet quia maxime aut rerum', 'at-ut-amet-quia-maxime-aut-rerum', '<p>Brief</p>\n<p><!-- pagebreak --></p>\n<p><a href=\"/public/images/tmp/708-11_1.jpg\">/public/images/tmp/708-11_1.jpg</a></p>\n<p></p>\n<p><img src=\"/public/images/revolution/001.jpg\" width=\"560\" height=\"350\" caption=\"false\" /></p>'),
(1276, 'vi', 'post', 'Et commodi dolorum sed elit', 'et-commodi-dolorum-sed-elit', NULL),
(1277, 'vi', 'post', 'Eum ut exercitation quis hic Nam pariatur', 'eum-ut-exercitation-quis-hic-nam-pariatur', '<p>Some brief</p>\n<p><!-- pagebreak --></p>\n<p>Load more brief</p>'),
(1278, 'vi', 'post', 'Est veniam autem assumenda eaque', 'est-veniam-autem-assumenda-eaque', '<p><img src=\"/images/post/1278/creative-design-pictures-green-city_2560x1600.jpg\" width=\"1000\" height=\"625\" class=\"img-responsive\" caption=\"false\" /></p>'),
(1279, 'vi', 'post', 'Ccslider 001', 'ccslider-001', NULL),
(1280, 'vi', 'post', 'Ccslider 002', 'ccslider-002', NULL),
(1281, 'vi', 'post', 'Ccslider 003', 'ccslider-003', NULL),
(1282, 'vi', 'post', 'Test table', 'test-table', '<table>\n<tbody>\n<tr>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n</tr>\n<tr>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n</tr>\n<tr>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n</tr>\n<tr>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n</tr>\n<tr>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n</tr>\n<tr>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n</tr>\n<tr>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n</tr>\n<tr>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n</tr>\n<tr>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n<td></td>\n</tr>\n<tr>\n<td>a</td>\n<td>a</td>\n<td>a</td>\n<td>a</td>\n<td>a</td>\n<td>a</td>\n<td>a</td>\n<td>a</td>\n<td>a</td>\n<td>h</td>\n</tr>\n</tbody>\n</table>'),
(1286, 'vi', 'post', 'Iure harum voluptates proident consequatur aut', 'iure-harum-voluptates-proident-consequatur-aut', NULL),
(1291, 'vi', 'post', 'Revolution 01', 'revolution-01', NULL),
(1294, 'vi', 'post', 'Revolution 02', 'revolution-02', NULL),
(1295, 'vi', 'post', 'Revolution 03', 'revolution-03', NULL),
(1296, 'vi', 'post', 'Eveniet ab dicta animi aut iusto voluptate', 'eveniet-ab-dicta-animi-aut-iusto-voluptate', NULL),
(1297, 'vi', 'post', 'Rerum aut quod aliquid labore maiores sint', 'rerum-aut-quod-aliquid-labore-maiores-sint', NULL),
(1298, 'vi', 'post', 'Excepturi earum non consequatur repudiandae', 'excepturi-earum-non-consequatur-repudiandae', NULL),
(1300, 'vi', 'post', 'Banner revolution 01', 'banner-revolution-01', NULL),
(1301, 'vi', 'post', 'Banner revolution 02', 'banner-revolution-02', NULL),
(1302, 'vi', 'post', 'Product 01', 'product-01', NULL),
(1303, 'vi', 'post', 'Product 02', 'product-02', NULL),
(1304, 'vi', 'post', 'Product 03', 'product-03', NULL),
(1305, 'vi', 'post', 'Product 04', 'product-04', NULL),
(1306, 'vi', 'post', 'Product 05', 'product-05', NULL),
(1307, 'vi', 'post', 'Product 06', 'product-06', NULL),
(1308, 'vi', 'post', 'Sổ tay', 'so-tay', NULL),
(1309, 'vi', 'post', 'Bút bi', 'but-bi', NULL),
(1310, 'vi', 'post', 'Bút kim loại', 'but-kim-loai', NULL),
(1311, 'vi', 'post', 'Áo mưa/ Ô dù', 'ao-mua-o-du', NULL),
(1312, 'vi', 'post', 'Hộp đựng danh thiếp', 'hop-dung-danh-thiep', NULL),
(1313, 'vi', 'post', 'Móc khóa', 'moc-khoa', NULL),
(1314, 'vi', 'post', 'Bình giữ nhiệt', 'binh-giu-nhiet', NULL),
(1315, 'vi', 'post', 'Bộ ly tách thủy tinh/ sứ', 'bo-ly-tach-thuy-tinh-su', NULL),
(1316, 'vi', 'post', 'Bao lô túi xách', 'bao-lo-tui-xach', NULL),
(1317, 'vi', 'post', 'Túi vải k dệt – vải bố', 'tui-vai-k-det-vai-bo', NULL),
(1318, 'vi', 'post', 'Bảng tên – dây treo thẻ Nhân viên', 'bang-ten-day-treo-the-nhan-vien', NULL),
(1319, 'vi', 'post', 'Quạt quảng cáo', 'quat-quang-cao', NULL),
(1320, 'vi', 'post', 'Đồng hồ', 'dong-ho', NULL),
(1321, 'vi', 'post', 'USB', 'usb', NULL),
(1322, 'vi', 'post', 'Nón – Đồng phục', 'non-dong-phuc', NULL),
(1323, 'vi', 'post', 'Name Card', 'name-card', NULL),
(1324, 'vi', 'post', 'Letter Head', 'letter-head', NULL),
(1325, 'vi', 'post', 'Bao Thư', 'bao-thu', NULL),
(1326, 'vi', 'post', 'Bìa đựng hồ sơ', 'bia-dung-ho-so', NULL),
(1327, 'vi', 'post', 'Bút/ Viết', 'but-viet', NULL),
(1328, 'vi', 'post', 'Văn phòng phẩm', 'van-phong-pham', NULL),
(1329, 'vi', 'post', 'Khác', 'khac', NULL),
(1330, 'vi', 'post', 'Tờ rơi / Tờ gấp', 'to-roi-to-gap', NULL),
(1331, 'vi', 'post', 'Brochure / Catalogue / Profile', 'brochure-catalogue-profile', NULL),
(1332, 'vi', 'post', 'Phiếu quà tặng/ Voucher', 'phieu-qua-tang-voucher', NULL),
(1333, 'vi', 'post', 'Thiệp mời / Thiệp cưới', 'thiep-moi-thiep-cuoi', NULL),
(1334, 'vi', 'post', 'Sổ tay', 'so-tay', NULL),
(1335, 'vi', 'post', 'Băng rôn ( Hiflex, PP, Decal, Format, Canvas, Silk) , Giấy ảnh', 'bang-ron-hiflex-pp-decal-format-canvas-silk-giay-anh', NULL),
(1336, 'vi', 'post', 'Thẻ nhựa ( thẻ Vip)', 'the-nhua-the-vip', NULL),
(1337, 'vi', 'post', 'Bao lì xì / Lịch', 'bao-li-xi-lich', NULL),
(1338, 'vi', 'post', 'Khác', 'khac', NULL),
(1339, 'vi', 'post', 'Nhãn Decal giấy', 'nhan-decal-giay', NULL),
(1340, 'vi', 'post', 'Bao bì hộp giấy', 'bao-bi-hop-giay', NULL),
(1341, 'vi', 'post', 'Hộp sản phẩm', 'hop-san-pham', NULL),
(1342, 'vi', 'post', 'Hộp quà', 'hop-qua', NULL),
(1343, 'vi', 'post', 'Bao đựng đũa, giấy trãi bàn nhà hàng / khách sạn', 'bao-dung-dua-giay-trai-ban-nha-hang-khach-san', NULL),
(1344, 'vi', 'post', 'Bao đựng bánh mì', 'bao-dung-banh-mi', NULL),
(1345, 'vi', 'post', 'Bao bì nhựa/ nilon/ màng co', 'bao-bi-nhua-nilon-mang-co', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wg_language`
--

CREATE TABLE `wg_language` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('active','deactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `priority` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_language`
--

INSERT INTO `wg_language` (`id`, `title`, `code`, `country`, `status`, `priority`) VALUES
(1, 'Vietnamese', 'vi', 'vi_VN', 'active', 1),
(2, 'English', 'en', 'en_US', 'deactive', 2);

-- --------------------------------------------------------

--
-- Table structure for table `wg_menu`
--

CREATE TABLE `wg_menu` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `priority` tinyint(4) NOT NULL,
  `display` enum('text','icon','icon_text') COLLATE utf8_unicode_ci DEFAULT 'text',
  `type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('active','deactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `open_in` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '_self',
  `class` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `width_column` smallint(5) UNSIGNED NOT NULL DEFAULT '200',
  `max_column` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `show_title` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  `route` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_menu`
--

INSERT INTO `wg_menu` (`id`, `parent`, `priority`, `display`, `type`, `status`, `open_in`, `class`, `width_column`, `max_column`, `show_title`, `route`, `data`, `created_at`, `updated_at`) VALUES
(100, 0, 1, 'text', 'homepage', 'deactive', '_self', NULL, 200, 1, 'yes', 'homepage', NULL, '2016-10-06 18:38:40', '2016-10-06 18:38:40'),
(101, 0, 3, 'text', 'separator', 'active', '_self', NULL, 750, 3, 'yes', 'post', NULL, '2016-10-06 18:40:53', '2016-10-06 18:40:53'),
(105, 0, 2, 'text', 'separator', 'active', '_self', NULL, 720, 3, 'yes', NULL, NULL, '2016-10-07 14:27:08', '2016-10-07 14:27:08'),
(106, 0, 4, 'text', 'separator', 'active', '_self', NULL, 600, 2, 'yes', NULL, NULL, '2016-10-07 14:53:22', '2016-10-07 14:53:22'),
(124, 105, 1, 'text', 'separator', 'active', '_self', NULL, 200, 1, 'no', NULL, NULL, '2016-11-09 07:26:58', '2016-11-09 07:26:58'),
(125, 105, 2, 'text', 'separator', 'active', '_self', NULL, 200, 1, 'no', NULL, NULL, '2016-11-09 07:27:07', '2016-11-09 07:27:07'),
(126, 105, 3, 'text', 'separator', 'active', '_self', NULL, 200, 1, 'no', NULL, NULL, '2016-11-09 07:27:14', '2016-11-09 07:27:14'),
(130, 0, 6, 'text', 'contact', 'active', '_self', NULL, 200, 1, 'yes', 'contactGet', NULL, '2017-03-31 20:38:36', '2017-03-31 20:38:36'),
(131, 0, 5, 'text', 'separator', 'active', '_self', NULL, 200, 1, 'yes', NULL, NULL, '2017-04-01 06:09:27', '2017-04-01 06:09:27'),
(132, 124, 1, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1308', '2017-04-01 06:13:05', '2017-04-01 06:13:05'),
(133, 124, 2, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1309', '2017-04-01 06:13:17', '2017-04-01 06:13:17'),
(134, 124, 3, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1310', '2017-04-01 06:13:29', '2017-04-01 06:13:29'),
(135, 124, 4, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1311', '2017-04-01 06:13:42', '2017-04-01 06:13:42'),
(136, 124, 5, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1312', '2017-04-01 06:13:52', '2017-04-01 06:13:52'),
(137, 125, 1, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1313', '2017-04-01 06:14:26', '2017-04-01 06:14:26'),
(138, 125, 2, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1314', '2017-04-01 06:14:37', '2017-04-01 06:14:37'),
(139, 125, 3, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1315', '2017-04-01 06:14:48', '2017-04-01 06:14:48'),
(140, 125, 4, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1316', '2017-04-01 06:14:59', '2017-04-01 06:14:59'),
(141, 125, 5, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1317', '2017-04-01 06:15:10', '2017-04-01 06:15:10'),
(142, 126, 1, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1318', '2017-04-01 06:15:21', '2017-04-01 06:15:21'),
(143, 126, 2, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1319', '2017-04-01 06:15:31', '2017-04-01 06:15:31'),
(144, 126, 3, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1320', '2017-04-01 06:15:40', '2017-04-01 06:15:40'),
(145, 126, 4, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1321', '2017-04-01 06:15:49', '2017-04-01 06:15:49'),
(146, 126, 5, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1322', '2017-04-01 06:16:00', '2017-04-01 06:16:00'),
(147, 101, 1, 'text', 'separator', 'active', '_self', NULL, 200, 1, 'yes', NULL, NULL, '2017-04-01 06:16:49', '2017-04-01 06:16:49'),
(148, 101, 2, 'text', 'separator', 'active', '_self', NULL, 200, 1, 'yes', NULL, NULL, '2017-04-01 06:17:27', '2017-04-01 06:17:27'),
(149, 101, 3, 'text', 'separator', 'active', '_self', NULL, 200, 1, 'yes', NULL, NULL, '2017-04-01 06:17:49', '2017-04-01 06:17:49'),
(150, 147, 1, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1323', '2017-04-01 06:18:06', '2017-04-01 06:18:06'),
(151, 147, 2, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1324', '2017-04-01 06:18:18', '2017-04-01 06:18:18'),
(152, 147, 3, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1325', '2017-04-01 06:18:28', '2017-04-01 06:18:28'),
(153, 147, 4, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1326', '2017-04-01 06:18:41', '2017-04-01 06:18:41'),
(154, 147, 5, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1327', '2017-04-01 06:18:53', '2017-04-01 06:18:53'),
(155, 147, 6, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1328', '2017-04-01 06:19:14', '2017-04-01 06:19:14'),
(156, 147, 7, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1329', '2017-04-01 06:19:24', '2017-04-01 06:19:24'),
(157, 148, 1, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1330', '2017-04-01 06:20:03', '2017-04-01 06:20:03'),
(158, 148, 2, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1331', '2017-04-01 06:20:14', '2017-04-01 06:20:14'),
(159, 148, 3, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1332', '2017-04-01 06:20:28', '2017-04-01 06:20:28'),
(160, 148, 4, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1333', '2017-04-01 06:20:40', '2017-04-01 06:20:40'),
(161, 148, 5, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1334', '2017-04-01 06:20:54', '2017-04-01 06:20:54'),
(162, 148, 6, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1335', '2017-04-01 06:21:10', '2017-04-01 06:21:10'),
(163, 148, 7, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1336', '2017-04-01 06:21:22', '2017-04-01 06:21:22'),
(164, 148, 8, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1337', '2017-04-01 06:21:35', '2017-04-01 06:21:35'),
(165, 148, 9, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1338', '2017-04-01 06:21:46', '2017-04-01 06:21:46'),
(166, 149, 1, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1339', '2017-04-01 06:22:01', '2017-04-01 06:22:01'),
(167, 149, 2, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1340', '2017-04-01 06:22:22', '2017-04-01 06:22:22'),
(168, 149, 3, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1341', '2017-04-01 06:22:33', '2017-04-01 06:22:33'),
(169, 149, 4, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1342', '2017-04-01 06:22:43', '2017-04-01 06:22:43'),
(170, 149, 5, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1343', '2017-04-01 06:22:55', '2017-04-01 06:22:55'),
(171, 149, 6, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1344', '2017-04-01 06:23:06', '2017-04-01 06:23:06'),
(172, 149, 7, 'text', 'post', 'active', '_self', NULL, 200, 1, 'yes', NULL, '1345', '2017-04-01 06:23:18', '2017-04-01 06:23:18'),
(173, 131, 1, 'text', 'category', 'active', '_self', NULL, 200, 1, 'yes', NULL, '120', '2017-04-01 06:24:39', '2017-04-01 06:24:39'),
(174, 131, 2, 'text', 'category', 'active', '_self', NULL, 200, 1, 'yes', NULL, '121', '2017-04-01 06:26:40', '2017-04-01 06:26:40');

-- --------------------------------------------------------

--
-- Table structure for table `wg_misc`
--

CREATE TABLE `wg_misc` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting` text COLLATE utf8_unicode_ci,
  `stat` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_misc`
--

INSERT INTO `wg_misc` (`id`, `setting`, `stat`) VALUES
(0, '{\"siteName\":\"C\\u00f4ng ty TNHH Th\\u00e1i S\\u01a1n Olympus\",\"siteDescription\":\"IN \\u1ea4N: L\\u00e0 m\\u1ed9t c\\u00f4ng ty In \\u1ea5n chuy\\u00ean nghi\\u1ec7p v\\u00e0 ho\\u1ea1t \\u0111\\u1ed9ng v\\u1ec1 l\\u0129nh v\\u1ef1c in \\u1ea5n trong nhi\\u1ec1u n\\u0103m, s\\u1ea3n ph\\u1ea9m in \\u1ea5n v\\u00e0 d\\u1ecbch v\\u1ee5 c\\u1ee7a ch\\u00fang t\\u00f4i cung c\\u1ea5p \\u0111a d\\u1ea1ng v\\u00e0 nhi\\u1ec1u h\\u00ecnh th\\u1ee9c nh\\u01b0: Danh thi\\u1ebfp, bi\\u1ec3u m\\u1eabu v\\u0103n ph\\u00f2ng (Phi\\u1ebfu xu\\u1ea5t - nh\\u1eadp kho, phi\\u1ebfu ra v\\u00e0o c\\u1ed5ng, bi\\u00ean nh\\u1eadn b\\u00e1n h\\u00e0ng...), gi\\u1ea5y ti\\u00eau \\u0111\\u1ec1, tem, nh\\u00e3n, bao th\\u01b0, folder, brochure, l\\u1ecbch, s\\u1ed5 tay, thi\\u1ec7p ch\\u00fac m\\u1eebng, thi\\u1ec7p m\\u1eddi, b\\u1eb1ng khen, gi\\u1ea5y ch\\u1ee9ng nh\\u1eadn, bao b\\u00ec, t\\u00faix \\u00e1ch gi\\u1ea5y, catalogue,\\u2026 \\n\\nQU\\u00c0 T\\u1eb6NG: T\\u1eb7ng qu\\u00e0 l\\u00e0 c\\u00e1ch ch\\u00fang ta th\\u1ec3 hi\\u1ec7n s\\u1ef1 quan t\\u00e2m \\u0111\\u1ebfn nhau. Ch\\u00fang t\\u00f4i mong mu\\u1ed1n l\\u00e0 c\\u1ea7u n\\u1ed1i trung gian gi\\u1eefa doanh nghi\\u1ec7p v\\u00e0 kh\\u00e1ch h\\u00e0ng chia s\\u1ebb, g\\u1eedi g\\u1eafm t\\u00e2m nguy\\u1ec7n c\\u1ee7a m\\u00ecnh v\\u00e0o m\\u1ed9t m\\u00f3n qu\\u00e0 \\u00fd ngh\\u0129a. \\u0110\\u1ebfn v\\u1edbi ch\\u00fang t\\u00f4i l\\u00e0 b\\u1ea1n \\u0111\\u01b0\\u1ee3c \\u0111\\u1ebfn v\\u1edbi th\\u1ebf gi\\u1edbi c\\u1ee7a qu\\u00e0 t\\u1eb7ng v\\u00e0 \\u1edf \\u0111\\u00e2y b\\u1ea1n c\\u00f3 th\\u1ec3 an t\\u00e2m khi g\\u1eedi ni\\u1ec1m tin c\\u1ee7a m\\u00ecnh. Ch\\u00fang t\\u00f4i mang \\u0111\\u1ebfn nhi\\u1ec1u m\\u1eb7t h\\u00e0ng \\u0111\\u1ec3 qu\\u00fd kh\\u00e1ch h\\u00e0ng l\\u1ef1a ch\\u1ecdn cho c\\u00e1c s\\u1ef1 ki\\u1ec7n quan tr\\u1ecdng.\",\"siteKeyword\":\"C\\u00f4ng ty TNHH Th\\u00e1i S\\u01a1n Olympus, In \\u1ea5n, Qu\\u00e0 t\\u1eb7ng\",\"siteContactEmail\":\"thanhson_it201@yahoo.com\",\"siteOnline\":\"1\",\"siteMessage\":\"Website down for maintenance. Please come back later!\\n\\nWebsite \\u0111ang b\\u1ea3o tr\\u00ec. Vui l\\u00f2ng quay l\\u1ea1i sau!\",\"adminTemplate\":\"admin_wargon\",\"webTemplate\":\"web_olympus\",\"language\":\"vi\",\"itemPerPage\":\"20\",\"postPerPage\":\"6\",\"userActive\":\"1\",\"analyticId\":null,\"sessionExpire\":\"180\",\"cacheExpire\":\"180\",\"watermark\":\"1\",\"watermarkText\":\"Wargon\",\"watermarkFont\":\"Tahoma\",\"watermarkDynamicColor\":\"1\",\"watermarkColorCode\":null,\"maxPostWidth\":\"800\",\"maxPostHeight\":\"600\",\"mailSmtpServer\":\"smtp.gmail.com\",\"mailSmtpSeverPort\":\"465\",\"mailUsername\":\"wedesignplus.com@gmail.com\",\"mailPassword\":\"thanhson\",\"mailName\":\"Wargon\"}', '{\"user\":13,\"post\":67,\"postVisit\":259,\"postPageview\":1189,\"mySqlVersion\":\"5.6.35\"}');

-- --------------------------------------------------------

--
-- Table structure for table `wg_post`
--

CREATE TABLE `wg_post` (
  `id` int(10) UNSIGNED NOT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('active','deactive','trash') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `user` int(10) UNSIGNED NOT NULL,
  `format` enum('standard','image') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'standard',
  `feature` text COLLATE utf8_unicode_ci,
  `visit` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pageview` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_post`
--

INSERT INTO `wg_post` (`id`, `tag`, `category`, `image`, `status`, `user`, `format`, `feature`, `visit`, `pageview`, `created_at`, `updated_at`) VALUES
(1268, 'Exercitationem autem nostrum fugiat ut libero hic et ut nemo id et beatae voluptatum consequatur aliqua Ex', NULL, NULL, 'active', 19191, 'standard', NULL, 3, 11, '2016-09-07 15:19:23', '2016-09-07 15:19:30'),
(1270, 'Ut perspiciatis nostrum atque eius non laboris quaerat ratione ad dolores sit non non incidunt est', NULL, NULL, 'active', 19191, 'standard', NULL, 2, 6, '2016-09-07 15:19:40', '2016-09-07 15:19:48'),
(1271, 'Dolore sint sed reprehenderit ipsum quas in', NULL, NULL, 'active', 19191, 'standard', NULL, 3, 16, '2016-09-07 15:19:48', '2016-09-07 15:19:56'),
(1272, 'Doloribus ab vitae est architecto sunt ut', NULL, NULL, 'active', 19191, 'standard', NULL, 4, 9, '2016-09-07 15:19:57', '2016-09-07 15:20:05'),
(1273, 'Hic molestias autem doloribus ad omnis consequuntur accusantium id fugiat non', NULL, 'images/post/1273/minions_014.jpg', 'active', 19191, 'standard', NULL, 4, 11, '2016-09-07 15:20:05', '2016-09-07 15:20:13'),
(1274, 'Magnam iste voluptatem veniam adipisicing tempor est perferendis vero dolor soluta quo', NULL, NULL, 'active', 19191, 'standard', NULL, 3, 17, '2016-09-07 15:20:13', '2016-09-07 15:20:21'),
(1275, 'Doloremque omnis deserunt debitis aut ex assumenda nisi', NULL, 'images/post/1275/creative-design-pictures-green-city_2560x1600.jpg', 'active', 19191, 'standard', NULL, 6, 14, '2016-09-07 15:20:21', '2016-09-07 15:20:29'),
(1276, 'Doloremque quae ea fugit ex', NULL, NULL, 'active', 19191, 'standard', NULL, 2, 13, '2016-09-12 16:02:53', '2016-09-12 16:03:05'),
(1277, 'Voluptas ut voluptate aspernatur veniam rerum iusto pariatur Magni excepteur qui quia id iusto doloribus aliquid non est voluptate', NULL, '/images/post/1277/img-03.jpg', 'active', 19191, 'standard', '{}', 9, 26, '2016-10-07 15:00:18', '2016-10-07 15:00:26'),
(1278, 'Similique quisquam autem sed nihil ut fugit iure reprehenderit aspernatur incididunt', NULL, 'images/post/1278/creative-design-pictures-green-city_2560x1600.jpg', 'active', 19191, 'standard', NULL, 27, 70, '2016-10-07 15:00:28', '2016-10-07 15:00:43'),
(1279, NULL, '116', 'images/post/1279/banner-03.jpg', 'deactive', 19191, 'image', NULL, 18, 174, '2016-11-03 16:19:10', '2016-11-03 16:21:04'),
(1280, NULL, '116', 'images/post/1280/banner-02.jpg', 'deactive', 19191, 'image', NULL, 9, 32, '2016-11-03 16:21:29', '2016-11-03 16:21:51'),
(1281, NULL, '116', 'images/post/1281/banner-01.jpg', 'deactive', 19191, 'image', NULL, 43, 228, '2016-11-03 16:21:52', '2016-11-03 16:22:25'),
(1282, NULL, NULL, NULL, 'active', 19191, 'standard', '{}', 14, 78, '2016-11-08 15:34:52', '2016-11-08 15:35:45'),
(1286, 'Dolore soluta eiusmod dolorem sequi ipsam nostrum', NULL, 'images/post/1286/minions_002.jpg', 'active', 19191, 'standard', '{}', 26, 185, '2017-03-30 18:57:24', '2017-01-05 05:20:47'),
(1291, NULL, '115', 'images/post/1291/1616-11.jpg', 'deactive', 19191, 'image', '{\"data-class\":[\"tp-caption tp-resizeme largewhitebg rs-parallaxlevel-3\"],\"data-frames\":[\"[{\\\"delay\\\": 0, \\\"speed\\\": 500, \\\"from\\\": \\\"opacity: 0\\\", \\\"to\\\": \\\"opacity: 1\\\"}, {\\\"delay\\\": \\\"wait\\\", \\\"speed\\\": 500, \\\"to\\\": \\\"opacity: 0\\\"}]\"],\"data-height\":[\"[\'auto\']\"],\"data-hoffset\":[\"0\"],\"data-title\":[\"Revolution new\"],\"data-voffset\":[\"0\"],\"data-width\":[\"[\'auto\']\"],\"data-x\":[\"center\"],\"data-y\":[\"center\"]}', 4, 13, '2017-03-27 18:45:26', '2017-03-27 18:48:42'),
(1294, NULL, '115', 'images/post/1294/1682-11.jpg', 'deactive', 19191, 'image', '{\"data-class\":[\"tp-caption tp-resizeme largewhitebg rs-parallaxlevel-3\"],\"data-frames\":[\"[{\\\"delay\\\": 0, \\\"speed\\\": 500, \\\"from\\\": \\\"opacity: 0\\\", \\\"to\\\": \\\"opacity: 1\\\"}, {\\\"delay\\\": \\\"wait\\\", \\\"speed\\\": 500, \\\"to\\\": \\\"opacity: 0\\\"}]\"],\"data-height\":[\"[\'auto\']\"],\"data-hoffset\":[\"0\"],\"data-title\":[\"Revolution 02\"],\"data-voffset\":[\"0\"],\"data-width\":[\"[\'auto\']\"],\"data-x\":[\"center\"],\"data-y\":[\"center\"]}', 3, 7, '2017-03-27 18:49:39', '2017-03-27 18:49:52'),
(1295, NULL, '115', 'images/post/1295/1886-11.jpg', 'deactive', 19191, 'image', '{\"data-frames\":[\"[{\\\"delay\\\": 0, \\\"speed\\\": 500, \\\"from\\\": \\\"opacity: 0\\\", \\\"to\\\": \\\"opacity: 1\\\"}, {\\\"delay\\\": \\\"wait\\\", \\\"speed\\\": 500, \\\"to\\\": \\\"opacity: 0\\\"}]\",\"[{\\\"delay\\\": 0, \\\"speed\\\": 500, \\\"from\\\": \\\"opacity: 0\\\", \\\"to\\\": \\\"opacity: 1\\\"}, {\\\"delay\\\": \\\"wait\\\", \\\"speed\\\": 500, \\\"to\\\": \\\"opacity: 0\\\"}]\"],\"data-x\":[\"center\",\"right\"],\"data-y\":[\"center\",\"bottom\"],\"data-hoffset\":[\"0\",\"0\"],\"data-voffset\":[\"0\",\"20\"],\"data-width\":[\"[\'auto\']\",\"[\'auto\']\"],\"data-height\":[\"[\'auto\']\",\"[\'auto\']\"],\"data-class\":[\"tp-caption tp-resizeme largewhitebg rs-parallaxlevel-3\",\"tp-caption tp-resizeme mediumwhitebg rs-parallaxlevel-1\"],\"data-title\":[\"Title test 0001\",\"Title test 0001 - 000002\"]}', 5, 14, '2017-03-27 18:49:55', '2017-03-27 18:50:06'),
(1296, 'Veniam atque praesentium quis quisquam vel ad est sunt autem officiis eum ut perspiciatis earum consequat Fugiat voluptas voluptate', NULL, NULL, 'active', 19191, 'standard', NULL, 10, 19, '2017-03-30 20:11:51', '2017-03-30 20:12:01'),
(1297, 'Tempora odit in ducimus eum sunt illum sunt eos corrupti inventore libero sit eius et quo culpa et', '120,121', NULL, 'active', 19191, 'standard', NULL, 23, 71, '2017-03-30 20:12:05', '2017-03-30 20:12:13'),
(1298, 'Deserunt cillum amet optio aut cupidatat et ut atque at velit et', '120,121', NULL, 'active', 19191, 'standard', NULL, 18, 61, '2017-03-30 20:12:13', '2017-03-30 20:12:20'),
(1300, NULL, '115', 'public/images/post/1300/img-01.jpg', 'active', 19191, 'image', '{\"data-class\":[\"tp-caption tp-resizeme largewhitebg rs-parallaxlevel-3\"],\"data-frames\":[\"[{\\\"delay\\\": 0, \\\"speed\\\": 500, \\\"from\\\": \\\"opacity: 0\\\", \\\"to\\\": \\\"opacity: 1\\\"}, {\\\"delay\\\": \\\"wait\\\", \\\"speed\\\": 500, \\\"to\\\": \\\"opacity: 0\\\"}]\"],\"data-height\":[\"[\'auto\']\"],\"data-hoffset\":[\"0\"],\"data-title\":[\"Công ty Thái Sơn Olympus\"],\"data-voffset\":[\"0\"],\"data-width\":[\"[\'auto\']\"],\"data-x\":[\"right\"],\"data-y\":[\"bottom\"]}', 6, 13, '2017-04-02 07:11:14', '2017-04-01 08:32:27'),
(1301, NULL, '115', 'public/images/post/1301/img-02.jpg', 'active', 19191, 'image', '{}', 4, 9, '2017-04-01 08:32:28', '2017-04-01 08:32:47'),
(1302, NULL, '119', 'public/images/post/1302/work-1.jpg', 'active', 19191, 'image', NULL, 1, 3, '2017-04-06 08:21:58', '2017-04-06 08:22:43'),
(1303, NULL, '119', 'public/images/post/1303/work-2.jpg', 'active', 19191, 'image', NULL, 0, 2, '2017-04-06 08:22:44', '2017-04-06 08:23:04'),
(1304, NULL, '119', 'public/images/post/1304/work-3.jpg', 'active', 19191, 'image', NULL, 0, 2, '2017-04-06 08:23:05', '2017-04-06 08:23:27'),
(1305, NULL, '119', 'public/images/post/1305/work-4.jpg', 'active', 19191, 'image', NULL, 0, 2, '2017-04-06 08:23:27', '2017-04-06 08:23:48'),
(1306, NULL, '119', 'public/images/post/1306/work-5.jpg', 'active', 19191, 'image', NULL, 0, 2, '2017-04-06 08:23:48', '2017-04-06 08:24:07'),
(1307, NULL, '119', 'public/images/post/1307/work-6.jpg', 'active', 19191, 'image', NULL, 0, 2, '2017-04-06 08:24:08', '2017-04-06 08:24:54'),
(1308, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 3, 12, '2017-04-06 08:49:00', '2017-04-06 08:49:44'),
(1309, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 08:49:44', '2017-04-06 08:49:53'),
(1310, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 08:49:53', '2017-04-06 08:50:05'),
(1311, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 08:50:06', '2017-04-06 08:50:12'),
(1312, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 1, 3, '2017-04-06 08:50:13', '2017-04-06 08:50:18'),
(1313, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 08:50:25', '2017-04-06 08:50:31'),
(1314, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 2, 3, '2017-04-06 08:50:32', '2017-04-06 08:50:38'),
(1315, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 08:50:39', '2017-04-06 08:50:45'),
(1316, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 08:50:45', '2017-04-06 08:50:51'),
(1317, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 08:50:51', '2017-04-06 08:50:59'),
(1318, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 2, 8, '2017-04-06 08:50:59', '2017-04-06 08:51:07'),
(1319, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 2, 17, '2017-04-06 08:51:08', '2017-04-06 08:51:13'),
(1320, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 08:51:14', '2017-04-06 08:51:20'),
(1321, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 08:51:20', '2017-04-06 08:51:26'),
(1322, NULL, '106', NULL, 'active', 19191, 'standard', NULL, 1, 2, '2017-04-06 08:51:26', '2017-04-06 08:51:32'),
(1323, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:38:31', '2017-04-06 09:38:45'),
(1324, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:38:46', '2017-04-06 09:38:53'),
(1325, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:38:53', '2017-04-06 09:39:00'),
(1326, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:39:01', '2017-04-06 09:39:07'),
(1327, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:39:07', '2017-04-06 09:39:13'),
(1328, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:39:14', '2017-04-06 09:39:23'),
(1329, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:39:23', '2017-04-06 09:39:29'),
(1330, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 1, 3, '2017-04-06 09:39:30', '2017-04-06 09:39:36'),
(1331, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:39:36', '2017-04-06 09:39:43'),
(1332, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:39:44', '2017-04-06 09:39:55'),
(1333, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:39:55', '2017-04-06 09:40:04'),
(1334, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:40:05', '2017-04-06 09:40:11'),
(1335, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:40:12', '2017-04-06 09:40:18'),
(1336, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:40:18', '2017-04-06 09:40:25'),
(1337, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:40:25', '2017-04-06 09:40:31'),
(1338, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:40:32', '2017-04-06 09:40:39'),
(1339, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:40:40', '2017-04-06 09:40:48'),
(1340, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:40:48', '2017-04-06 09:41:01'),
(1341, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:41:01', '2017-04-06 09:41:08'),
(1342, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:41:08', '2017-04-06 09:41:14'),
(1343, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:41:14', '2017-04-06 09:41:22'),
(1344, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:41:22', '2017-04-06 09:41:31'),
(1345, NULL, '105', NULL, 'active', 19191, 'standard', NULL, 0, 1, '2017-04-06 09:41:31', '2017-04-06 09:41:39');

-- --------------------------------------------------------

--
-- Table structure for table `wg_post_extra`
--

CREATE TABLE `wg_post_extra` (
  `id` int(10) UNSIGNED NOT NULL,
  `href` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `target` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_post_extra`
--

INSERT INTO `wg_post_extra` (`id`, `href`, `target`) VALUES
(1279, '//google.com.vn', '_self'),
(1280, '//youtube.com', '_self'),
(1281, '//facebook.com', '_self'),
(1283, NULL, '_self'),
(1284, '//youtube.com', '_self'),
(1285, NULL, '_self'),
(1287, NULL, '_blank'),
(1291, '#', '_self'),
(1294, '#', '_self'),
(1295, '#', '_self'),
(1300, '#', '_self'),
(1301, '#', '_self'),
(1302, '#', '_self'),
(1303, '#', '_self'),
(1304, '#', '_self'),
(1305, '#', '_self'),
(1306, '#', '_self'),
(1307, '#', '_self');

-- --------------------------------------------------------

--
-- Table structure for table `wg_post_feature`
--

CREATE TABLE `wg_post_feature` (
  `feature` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_post_feature`
--

INSERT INTO `wg_post_feature` (`feature`) VALUES
('data-class'),
('data-frames'),
('data-height'),
('data-hoffset'),
('data-title'),
('data-voffset'),
('data-width'),
('data-x'),
('data-y');

-- --------------------------------------------------------

--
-- Table structure for table `wg_sessions`
--

CREATE TABLE `wg_sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8_unicode_ci,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_sessions`
--

INSERT INTO `wg_sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('tORfK35pSJsD6agIPUIirtFGnZtPCoEsV5odWdUs', 19229, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'YTo4OntzOjY6Il90b2tlbiI7czo0MDoicTlmODZuV0J2RVpsM3NuZ2sybHFlOG9vcjR6eFpuWWtwZTdqQk9ZUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly9vbHltcHVzLmRldi9hZG1pbi9wb3N0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJ2aXNpdFBvc3QiO2E6MTp7aToxMzMwO2k6MTQ5MjUzNjYyOTt9czo3OiJjYXB0Y2hhIjtzOjY6Ind5c1hWTCI7czoxMDoic3lzdGVtU3RhdCI7Tzo4OiJzdGRDbGFzcyI6NTp7czo0OiJ1c2VyIjtpOjEzO3M6NDoicG9zdCI7aTo2NztzOjk6InBvc3RWaXNpdCI7aToyNTk7czoxMjoicG9zdFBhZ2V2aWV3IjtpOjExODk7czoxMjoibXlTcWxWZXJzaW9uIjtzOjY6IjUuNi4zNSI7fXM6MTQ6InN5c3RlbVN0YXRUaW1lIjtpOjE0OTI1Mzc3NTc7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTkyMjk7fQ==', 1492538970);

-- --------------------------------------------------------

--
-- Table structure for table `wg_user`
--

CREATE TABLE `wg_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` tinytext COLLATE utf8_unicode_ci,
  `role` enum('1','2','3','4','5','6','7','8','9') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `status` enum('trash','active','deactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'deactive',
  `subscribe` enum('no','yes') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  `register_ip` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active_ip` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hash_code` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hash_dt` timestamp NULL DEFAULT NULL,
  `logged_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_user`
--

INSERT INTO `wg_user` (`id`, `email`, `password`, `remember_token`, `name`, `birthday`, `phone`, `address`, `role`, `status`, `subscribe`, `register_ip`, `active_ip`, `hash_code`, `hash_dt`, `logged_at`, `created_at`, `updated_at`) VALUES
(19191, 'thanhson_it201@yahoo.com', '$2y$10$PNliese6E/GPhb58ELVk7ODPJTXSokWcRYA62086TxaxablMePh9u', 'qwAoxbLJKqlnVKscD6vWZ71IAe1Jopf4i4VqsO18lMlyyA22sKjAvqojbsKF', 'Wargon', '1990-01-20', '0938142212', 'Tan Binh', '9', 'active', 'no', '127.0.0.1', '127.0.0.1', NULL, NULL, '2017-04-18 17:49:17', '2014-09-25 17:00:00', '2017-01-15 18:04:49'),
(19217, 'wexutuc@gmail.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', 'NrsK4cKL75XM2kQzf31YyDPH7L4eEAgvdcDtlzeAcdzekkOZlU1CwA5zPVDC', 'Paloma Hogan', '2007-02-17', '65', 'Voluptas magnam quam et sunt molestiae proident, pariatur. Est pariatur. Animi, repudiandae ex ex.', '1', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-11 11:44:44', '2016-09-11 11:44:44', '2016-09-12 16:08:15'),
(19218, 'catalixo@hotmail.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', NULL, 'Raven Burks', '1983-06-11', '70', 'Vero minus architecto maiores et soluta dignissimos neque consequatur? Illo tempora exercitation at fugit, irure facere minima.', '3', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-11 11:44:46', '2016-09-11 11:44:46', '2016-09-11 11:44:46'),
(19219, 'merahas@hotmail.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', 'OtJUU3AzSewX82IXYLzEwiqqIDbPG3xdelZDWw791PBJYWxlDCzIOTP9aXsp', 'Justina Black', '2013-02-20', '5', 'Dolore deserunt deserunt aliqua. Dolor sed excepteur deserunt est quibusdam.', '3', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-12 16:50:39', '2016-09-11 11:44:49', '2016-09-12 17:18:03'),
(19220, 'lojy@yahoo.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', NULL, 'Xantha Morin', '1972-04-26', '24', 'Repudiandae ab neque iusto atque saepe consequat. Eos delectus, quia mollitia.', '1', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-11 11:44:56', '2016-09-11 11:44:56', '2016-09-11 11:44:56'),
(19221, 'rolyvilyfe@yahoo.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', '0qhkeIXKHERIHvhGZIjdZ3tjACgcbiestCpBftig8L6TY6KCGBbeJDFPtn9G', 'Ethan Deleon', '1987-03-18', '11', 'Nisi dolor quasi minima dolorem natus ut necessitatibus aut eveniet, quo in officia et excepturi voluptate.', '6', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-21 15:51:19', '2016-09-11 11:44:58', '2016-09-21 15:52:04'),
(19222, 'lylobyvere@gmail.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', NULL, 'Valentine Anderson', '1993-10-31', '40', 'Et magna voluptatibus voluptas sed cumque aute tempore, quisquam voluptas at officia asperiores necessitatibus error.', '3', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-11 11:45:01', '2016-09-11 11:45:01', '2016-09-11 11:45:01'),
(19223, 'fiwem@yahoo.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', 'TjADk5bmvo37vkcCquJsXtGqWPIDvXZ3Bld2jJCP6bCn7DCS7BbOHVfzgXvl', 'Fi wem', '1990-11-30', '72', 'Facilis occaecat molestiae sint unde rerum blanditiis fuga. Reiciendis autem provident, enim sed saepe harum adipisicing molestias.', '6', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-12 16:49:54', '2016-09-11 11:45:03', '2016-09-12 16:50:09'),
(19224, 'zypena@gmail.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', 'TMU8SEKGSGDuXnDpy05kxAU36KMr8AmVfsz74G8gsvTsivhWqN12PgUhSz7J', 'Adrian Jarvis', '1992-05-26', '7', 'Est aut duis irure proident, proident, irure qui eius perferendis repudiandae est, minim velit ratione.', '2', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-21 15:15:43', '2016-09-11 11:45:06', '2016-09-21 15:51:14'),
(19225, 'zyqo@yahoo.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', NULL, 'Melissa Kline', '1985-09-21', '63', 'Lorem odio sed quae explicabo. Aut ut aut quis est.', '6', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-11 11:45:08', '2016-09-11 11:45:08', '2016-09-11 11:45:08'),
(19226, 'xidefihic@hotmail.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', NULL, 'Faith Mayer', '2006-08-27', '61', 'Odio delectus, mollit recusandae. Praesentium culpa, eveniet, incidunt, veniam, aliquam perspiciatis, ipsum anim.', '1', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-11 11:45:11', '2016-09-11 11:45:11', '2016-09-11 11:45:11'),
(19227, 'wyve@hotmail.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', NULL, 'Vanna Whitehead', '1986-05-27', '23', 'Quis nihil ex deserunt eos quod in reprehenderit repudiandae fugiat quia laborum. Amet, minim modi voluptatem, reprehenderit, dolorem asperiores maxime.', '2', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-11 11:45:13', '2016-09-11 11:45:13', '2016-09-11 11:45:13'),
(19228, 'wekixob@gmail.com', '$2y$10$MpUWngLJdqrrAusb4Jgc/usRFrrDdGlZUPOZKZjmgzWl./shoxlZe', 'LlVdebcf08MPJPZH8TIOCi2cJK8uq6aXbuZG4tOKQXMGFWVW1VrLR32I4beD', 'Kieran Salas', '2012-11-29', '39', 'Sit et ut id, consectetur, sunt tempor mollitia eum porro ratione sed necessitatibus maiores perspiciatis, consectetur id.', '3', 'active', 'no', '::1', '::1', NULL, NULL, '2016-09-27 13:24:20', '2016-09-11 11:45:16', '2016-09-27 13:26:00'),
(19229, 'linh.vo@diadieminan.com', '$2y$10$2hOBm8HTxUz.XX3G8kMwquWSWutTxbtYm0v126R06z3c91AC7KPZ.', NULL, 'Linh Vo', '1990-02-14', NULL, NULL, '6', 'active', 'yes', '::1', '::1', NULL, NULL, '2017-04-18 18:05:14', '2017-04-18 17:50:39', '2017-04-18 17:50:39'),
(19230, 'vydokex@hotmail.com', '$2y$10$dhYYIR10U6VoayirYMmi5uBtDzdxoFQCaSmu7DVsGh8Ay6yg06Poq', NULL, NULL, NULL, NULL, NULL, '1', 'active', 'yes', '::1', '::1', NULL, NULL, NULL, '2017-04-18 18:03:58', '2017-04-18 18:03:58');

-- --------------------------------------------------------

--
-- Table structure for table `wg_user_online`
--

CREATE TABLE `wg_user_online` (
  `id` int(10) UNSIGNED NOT NULL,
  `time` int(10) UNSIGNED NOT NULL,
  `ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_user_online`
--

INSERT INTO `wg_user_online` (`id`, `time`, `ip`, `path`) VALUES
(36, 1492538523, '::1', '/admin/user/add'),
(41, 1492538641, '::1', '/admin/user/update'),
(40, 1492538638, '::1', '/admin/user/edit/19230'),
(34, 1492538438, '::1', '/admin/user'),
(39, 1492538637, '::1', '/admin/user/update'),
(38, 1492538633, '::1', '/admin/user/add'),
(35, 1492538439, '::1', '/admin/user'),
(37, 1492538628, '::1', '/admin/user/add'),
(10, 1492537604, '::1', '/'),
(11, 1492537751, '::1', '/admin'),
(12, 1492537751, '::1', '/admin'),
(13, 1492537752, '::1', '/admin/auth/login'),
(14, 1492537757, '::1', '/admin/auth/login'),
(15, 1492537757, '::1', '/admin'),
(16, 1492537762, '::1', '/admin/user'),
(17, 1492537765, '::1', '/admin/user/add'),
(18, 1492537799, '::1', '/admin/user/update'),
(19, 1492537806, '::1', '/admin/user/update'),
(20, 1492537839, '::1', '/admin/user/update'),
(21, 1492537839, '::1', '/admin/user/edit/19229'),
(22, 1492537845, '::1', '/admin/user/update'),
(23, 1492537845, '::1', '/admin/user'),
(24, 1492538043, '::1', '/admin/user'),
(25, 1492538088, '::1', '/admin/user'),
(26, 1492538164, '::1', '/admin/user'),
(27, 1492538195, '::1', '/admin/user'),
(28, 1492538222, '::1', '/admin/user'),
(29, 1492538242, '::1', '/admin/user'),
(30, 1492538254, '::1', '/admin/user'),
(31, 1492538301, '::1', '/admin/user'),
(32, 1492538314, '::1', '/admin/user'),
(33, 1492538331, '::1', '/admin/user'),
(42, 1492538642, '::1', '/admin/user'),
(43, 1492538698, '::1', '/admin/auth/logout'),
(44, 1492538698, '::1', '/admin/auth/login'),
(45, 1492538714, '::1', '/admin/auth/login'),
(46, 1492538715, '::1', '/admin'),
(47, 1492538724, '::1', '/admin/post'),
(48, 1492538820, '::1', '/admin/post'),
(49, 1492538881, '::1', '/admin/post'),
(50, 1492538885, '::1', '/admin/post'),
(51, 1492538888, '::1', '/admin/setting'),
(52, 1492538891, '::1', '/admin/user/role'),
(53, 1492538891, '::1', '/admin/user/role'),
(54, 1492538915, '::1', '/admin/user/role'),
(55, 1492538920, '::1', '/admin/widget'),
(56, 1492538922, '::1', '/admin/post'),
(57, 1492538924, '::1', '/admin/category/post'),
(58, 1492538925, '::1', '/admin/post'),
(59, 1492538929, '::1', '/admin/user'),
(60, 1492538939, '::1', '/admin/user/role'),
(61, 1492538970, '::1', '/admin/post');

-- --------------------------------------------------------

--
-- Table structure for table `wg_user_role`
--

CREATE TABLE `wg_user_role` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `accessible_place` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_user_role`
--

INSERT INTO `wg_user_role` (`id`, `title`, `accessible_place`) VALUES
(1, 'User', NULL),
(2, 'Content manager', '[\"dashboard\",\"content\",\"post\",\"banner\",\"product\",\"profile\"]'),
(3, 'Structure manager', '[\"dashboard\",\"content\",\"category\",\"menu\",\"widget\",\"profile\"]'),
(6, 'Moderator', '[\"dashboard\",\"user\",\"menu\",\"content\",\"post\",\"category\",\"banner\",\"product\",\"widget\"]'),
(9, 'Administrator', '[\"admin\",\"auth\",\"dashboard\",\"setting\",\"user\",\"menu\",\"content\",\"post\",\"category\",\"product\",\"widget\",\"component\",\"email\",\"faq\"]');

-- --------------------------------------------------------

--
-- Table structure for table `wg_widget`
--

CREATE TABLE `wg_widget` (
  `id` int(10) UNSIGNED NOT NULL,
  `priority` tinyint(4) NOT NULL,
  `position` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('active','deactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active' COMMENT '1: Enabled',
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `show_title` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no',
  `show_content` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  `visible_zone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assignment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `param` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wg_widget`
--

INSERT INTO `wg_widget` (`id`, `priority`, `position`, `status`, `type`, `show_title`, `show_content`, `visible_zone`, `assignment`, `param`, `created_at`, `updated_at`) VALUES
(2, 1, 'mainMenu', 'deactive', 'main-menu', 'no', 'yes', NULL, 'all', '{\"class_sfx\":\"\",\"timeDelay\":\"150\",\"timeToShowMenu\":\"250\",\"deviation\":\"30\"}', '2016-10-16 04:18:21', '2016-10-16 04:18:21'),
(8, 1, 'banner', 'active', 'banner', 'no', 'yes', '{\"visible-xs\":false,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_homepage', '{\"class_sfx\":null,\"cat_id\":\"115\",\"banner_type\":\"revolution\",\"background_color\":\"#ccc\",\"width\":\"1170\",\"height\":\"500\",\"image_width\":\"1920\",\"image_height\":\"500\",\"interval\":\"8000\",\"caption_display\":\"yes\",\"caption_position\":\"bottom\",\"ccslider_effect_type\":\"3d\",\"ccslider_effect_3d\":\"random\",\"ccslider_effect_2d\":\"random\",\"sliderLayout\":\"auto\",\"autoHeight\":\"off\",\"minHeight\":\"300\",\"navigationArrow\":\"uranus\",\"navigationBullet\":\"hesperiden\",\"touchEnabled\":\"on\",\"parallaxType\":\"mouse\"}', '2016-10-24 17:24:08', '2016-10-24 17:24:08'),
(9, 2, 'containerBottom', 'deactive', 'custom-html', 'no', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_homepage', '{\"class_sfx\":null}', '2016-10-24 17:41:13', '2016-10-24 17:41:13'),
(10, 2, 'containerTop', 'active', 'custom-html', 'no', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_homepage', '{\"class_sfx\":null}', '2016-10-24 17:42:35', '2016-10-24 17:42:35'),
(11, 1, 'containerTop', 'active', 'google-map', 'no', 'no', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_contactGet', '{\"class_sfx\":null,\"lat\":\"10.79685\",\"long\":\"106.64272\",\"zoom\":\"15\",\"width\":\"100%\",\"height\":\"300px\",\"backgroundColor\":\"grey\",\"apiKey\":\"AIzaSyApf9yEbuxg536hxcKhYVhEGIte6aWy1Es\"}', '2016-10-26 15:55:12', '2016-10-26 15:55:12'),
(12, 1, 'copyright', 'active', 'custom-html', 'no', 'yes', NULL, 'all', '{\"class_sfx\":\"\"}', '2016-10-26 15:56:20', '2016-10-26 15:56:20'),
(13, 1, 'footerMenu', 'active', 'custom-html', 'no', 'yes', NULL, 'all', '{\"class_sfx\":\"\"}', '2016-10-26 15:56:58', '2016-10-26 15:56:58'),
(14, 1, 'sidebarRight', 'active', 'custom-html', 'yes', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'post,category', '{\"class_sfx\":\"text\"}', '2016-10-26 16:01:23', '2016-10-26 16:01:23'),
(15, 4, 'sidebarRight', 'active', 'counter', 'yes', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'post,category', '{\"class_sfx\":null,\"initialvalue\":\"13680\",\"digit_type\":\"rainbow\",\"number_digits\":\"6\"}', '2016-10-26 16:10:47', '2016-10-26 16:10:47'),
(16, 3, 'sidebarRight', 'active', 'custom-html', 'no', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_contactGet', '{\"class_sfx\":null}', '2016-10-26 16:12:00', '2016-10-26 16:12:00'),
(17, 1, 'user1', 'active', 'custom-html', 'no', 'yes', NULL, 'all', '{\"class_sfx\":\"\"}', '2016-10-26 16:15:30', '2016-10-26 16:15:30'),
(18, 1, 'user2', 'active', 'custom-html', 'no', 'yes', NULL, 'all', '{\"class_sfx\":\"\"}', '2016-10-26 16:20:02', '2016-10-26 16:20:02'),
(19, 1, 'user3', 'active', 'custom-html', 'no', 'yes', NULL, 'all', '{\"class_sfx\":\"\"}', '2016-10-26 16:20:40', '2016-10-26 16:20:40'),
(20, 2, 'sidebarRight', 'active', 'post-sort', 'yes', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'post,category', '{\"class_sfx\":null,\"cat_id\":[\"112\",\"120\",\"121\"],\"post_format\":\"standard\",\"showBrief\":\"0\",\"ordering\":\"added\",\"limit\":\"5\",\"leadArticle\":\"no\"}', '2016-11-08 15:42:33', '2016-11-08 15:42:33'),
(21, 2, 'banner', 'deactive', 'banner', 'no', 'yes', '{\"visible-xs\":false,\"visible-sm\":false,\"visible-md\":false,\"visible-lg\":true}', 'web_homepage', '{\"class_sfx\":null,\"cat_id\":\"116\",\"banner_type\":\"ccslider\",\"background_color\":\"#ccc\",\"width\":\"1170\",\"height\":\"305\",\"image_width\":\"400\",\"image_height\":\"300\",\"interval\":\"2000\",\"caption_display\":\"yes\",\"caption_position\":\"bottom\",\"ccslider_effect_type\":\"3d\",\"ccslider_effect_3d\":\"random\",\"ccslider_effect_2d\":\"random\",\"delay\":\"8000\",\"startWidth\":\"890\",\"startHeight\":\"450\",\"hideThumbs\":\"200\",\"thumbWidth\":\"100\",\"thumbHeight\":\"50\",\"thumbAmount\":\"3\",\"navigationType\":\"bullet\",\"navigationArrows\":\"verticalcentered\",\"navigationStyle\":\"round\",\"touchenabled\":\"on\",\"onHoverStop\":\"on\",\"shadow\":\"0\",\"fullWidth\":\"on\",\"navOffsetHorizontal\":null,\"navOffsetVertical\":\"20\",\"stopAtSlide\":\"-1\",\"stopAfterLoops\":\"-1\"}', '2016-11-16 15:46:47', '2016-11-16 15:46:47'),
(22, 3, 'containerTop', 'active', 'custom-html', 'no', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_homepage', '{\"class_sfx\":null}', '2017-04-06 07:31:20', '2017-04-06 07:31:20'),
(23, 4, 'containerTop', 'active', 'custom-html', 'no', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_homepage', '{\"class_sfx\":null}', '2017-04-06 07:38:19', '2017-04-06 07:38:19'),
(24, 5, 'containerTop', 'active', 'custom-html', 'no', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_homepage', '{\"class_sfx\":null}', '2017-04-06 07:49:17', '2017-04-06 07:49:17'),
(25, 6, 'containerTop', 'active', 'custom-html', 'no', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_homepage', '{\"class_sfx\":null}', '2017-04-06 07:53:26', '2017-04-06 07:53:26'),
(26, 1, 'containerBottom', 'active', 'custom-html', 'no', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_homepage', '{\"class_sfx\":null}', '2017-04-06 07:56:23', '2017-04-06 07:56:23'),
(27, 3, 'containerBottom', 'active', 'custom-html', 'no', 'yes', '{\"visible-xs\":true,\"visible-sm\":true,\"visible-md\":true,\"visible-lg\":true}', 'web_homepage', '{\"class_sfx\":null}', '2017-04-06 08:17:09', '2017-04-06 08:17:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wg_category`
--
ALTER TABLE `wg_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wg_content`
--
ALTER TABLE `wg_content`
  ADD PRIMARY KEY (`id`,`lang`,`tbl`);

--
-- Indexes for table `wg_language`
--
ALTER TABLE `wg_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wg_menu`
--
ALTER TABLE `wg_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wg_misc`
--
ALTER TABLE `wg_misc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wg_post`
--
ALTER TABLE `wg_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wg_post_extra`
--
ALTER TABLE `wg_post_extra`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wg_post_feature`
--
ALTER TABLE `wg_post_feature`
  ADD PRIMARY KEY (`feature`);

--
-- Indexes for table `wg_sessions`
--
ALTER TABLE `wg_sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `wg_user`
--
ALTER TABLE `wg_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `auth` (`email`,`password`),
  ADD KEY `role` (`role`);

--
-- Indexes for table `wg_user_online`
--
ALTER TABLE `wg_user_online`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wg_user_role`
--
ALTER TABLE `wg_user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wg_widget`
--
ALTER TABLE `wg_widget`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wg_category`
--
ALTER TABLE `wg_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;
--
-- AUTO_INCREMENT for table `wg_language`
--
ALTER TABLE `wg_language`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `wg_menu`
--
ALTER TABLE `wg_menu`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;
--
-- AUTO_INCREMENT for table `wg_post`
--
ALTER TABLE `wg_post`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1346;
--
-- AUTO_INCREMENT for table `wg_user`
--
ALTER TABLE `wg_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19231;
--
-- AUTO_INCREMENT for table `wg_user_online`
--
ALTER TABLE `wg_user_online`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `wg_widget`
--
ALTER TABLE `wg_widget`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
